# HAMIMID Mourad - Personal Academic Website

Personal academic website for HAMIMID Mourad, University Teacher at the University of Bordj Bou Arreridj.

## Main sections
- Home
- About
- Teaching
- Research
- Contact

## Technologies
- HTML
- CSS
- JavaScript

The site is ready to be deployed with Vercel.
